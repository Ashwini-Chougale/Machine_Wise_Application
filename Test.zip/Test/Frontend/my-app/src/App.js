
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import MachineStatusDivs from './MachineStatusDivs'; 
import DataSummary from './DataSummary'; 
import DateTimeButton from './DateTimeButton'; 
import FilterButton from './FilterButton'; 

function App() {
  const [data, setData] = useState([]);
  const [startDate, setStartDate] = useState(new Date().toISOString());
  const [endDate, setEndDate] = useState(new Date().toISOString());

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/data');
        setData(response.data);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  const handleDateChange = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/data?fromDate=${startDate}&toDate=${endDate}`);
      setData(response.data);
    } catch (error) {
      console.error('Error fetching filtered data:', error);
    }
  };

  return (
    <div>
      <h1>Machine Status Visualization</h1>
      <DateTimeButton
        startDate={startDate}
        endDate={endDate}
        setStartDate={setStartDate}
        setEndDate={setEndDate}
        onClick={handleDateChange}
      />
      <FilterButton onClick={handleDateChange} />
      <MachineStatusDivs data={data} />
      <DataSummary data={data} />
    </div>
  );
}

export default App;
