import React from 'react';

const DateTimeButton = ({ startDate, endDate, setStartDate, setEndDate }) => {
  const handleStartDateChange = (e) => {
    setStartDate(e.target.value);
  };

  const handleEndDateChange = (e) => {
    setEndDate(e.target.value);
  };

  return (
    <div className="DateTimeButton">
      <input
        type="datetime-local"
        value={startDate}
        onChange={handleStartDateChange}
      />
      <input
        type="datetime-local"
        value={endDate}
        onChange={handleEndDateChange}
      />
    </div>
  );
};

export default DateTimeButton;
