import React from 'react';

const FilterButton = ({ onClick }) => {
  return (
    <button onClick={onClick} className="FilterButton">
      Filter Data
    </button>
  );
};

export default FilterButton;
