import React from 'react';

const Summary = ({ summary }) => {
  return (
    <div className="Summary">
      <h2>Summary</h2>
      <table>
        <thead>
          <tr>
            <th>Statistic</th>
            <th>Count</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Number of 0s</td>
            <td>{summary.numberOfZeros}</td>
          </tr>
          <tr>
            <td>Number of 1s</td>
            <td>{summary.numberOfOnes}</td>
          </tr>
          <tr>
            <td>Continuous 0s</td>
            <td>{summary.continuousZeros}</td>
          </tr>
          <tr>
            <td>Continuous 1s</td>
            <td>{summary.continuousOnes}</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default Summary;

