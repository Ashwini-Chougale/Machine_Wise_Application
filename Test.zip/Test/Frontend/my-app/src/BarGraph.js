import React, { useState, useEffect, useRef } from 'react';
import { Chart } from 'chart.js';
import { Bar } from 'react-chartjs-2';

const BarGraph = ({ data }) => {
  const [chartInstance, setChartInstance] = useState(null);
  const chartContainer = useRef(null);

  useEffect(() => {
    if (chartContainer && chartContainer.current) {
      const newChartInstance = new Chart(chartContainer.current, {
        type: 'bar',
        data: chartData,
        options: options,
      });

      setChartInstance(newChartInstance);
    }

    return () => {
      if (chartInstance) {
        chartInstance.destroy();
      }
    };
  }, [data]); // Re-run effect when data changes

  const chartData = {
    labels: data.map(item => item.ts),
    datasets: [
      {
        label: 'Vibration',
        data: data.map(item => item.vibration),
        backgroundColor: data.map(item => {
          if (item.machine_status === 0) return 'yellow';
          else if (item.machine_status === 1) return 'green';
          else return 'red';
        }),
      },
    ],
  };

  const options = {
    scales: {
      xAxes: [{
        ticks: {
          autoSkip: false,
        },
        type: 'time',
        time: {
          unit: 'second',
          displayFormats: {
            second: 'HH:mm:ss',
          },
        },
        scaleLabel: {
          display: true,
          labelString: 'Timestamp',
        },
      }],
      yAxes: [{
        ticks: {
          beginAtZero: true,
        },
        scaleLabel: {
          display: true,
          labelString: 'Vibration',
        },
      }],
    },
    legend: {
      display: true,
      position: 'top',
    },
  };

  return (
    <div style={{ width: '80%', margin: '20px auto' }}>
      <h2>Vibration Data</h2>
      <canvas ref={chartContainer} />
    </div>
  );
};

export default BarGraph;









