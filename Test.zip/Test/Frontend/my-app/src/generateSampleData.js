// sampleDataGenerator.js
import React from 'react';
// Function to generate sample data
const generateSampleData = () => {
    const samples = [];
    const now = new Date();
  
    for (let i = 0; i < 100; i++) {
      const timestamp = new Date(now.getTime() + i * 1000); // Increment timestamp
      const machineStatus = Math.random() < 0.5 ? 0 : 1; // Random 0 or 1
      const vibration = Math.floor(Math.random() * 1000); // Random vibration value
      samples.push({ timestamp, machineStatus, vibration });
    }
  
    return samples;
  };
  
  // Export the function
  export default generateSampleData;
  