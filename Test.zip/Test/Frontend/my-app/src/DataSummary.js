// DataSummaryTable.js

import React from 'react';

const DataSummary = ({ data }) => {
  const calculateSummary = () => {
    let ones = 0;
    let zeros = 0;
    let continuousOnes = 0;
    let continuousZeros = 0;

    for (let i = 0; i < data.length; i++) {
      if (data[i].machine_status === 1) {
        ones++;
        continuousOnes++;
        continuousZeros = 0;
      } else if (data[i].machine_status === 0) {
        zeros++;
        continuousZeros++;
        continuousOnes = 0;
      }
    }

    return {
      ones,
      zeros,
      continuousOnes,
      continuousZeros,
    };
  };

  const { ones, zeros, continuousOnes, continuousZeros } = calculateSummary();

  return (
    <div className="DataSummary">
      <h2>Data Summary</h2>
      <table>
        <thead>
          <tr>
            <th>Status</th>
            <th>Count</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>1s</td>
            <td>{ones}</td>
          </tr>
          <tr>
            <td>0s</td>
            <td>{zeros}</td>
          </tr>
          <tr>
            <td>Continuous 1s</td>
            <td>{continuousOnes}</td>
          </tr>
          <tr>
            <td>Continuous 0s</td>
            <td>{continuousZeros}</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default DataSummary;
