import React from 'react';

const MachineStatusDivs = ({ data }) => {
  const getStatusColor = (status) => {
    if (status === 0) {
      return 'yellow';
    } else if (status === 1) {
      return 'green';
    } else {
      return 'red'; // Assuming missing status should be red
    }
  };

  return (
<div className="container">
    <center>
    <div 
      style={{
        display: 'flex',
        flexDirection: 'row',
        width: '100%',
        height: '50px', // Height of the horizontal bar
        border: '1px solid black',
        overflowX: 'auto', // Horizontal scrollbar if needed
      }}
    >
      {data.map((item, index) => (
        <div
          key={index}
          style={{
            position: 'relative',
            width: '10px', // Width of each vertical line
            height: '100%',
          }}
        >
          <div
            style={{
              position: 'absolute',
              bottom: '0',
              left: '50%',
              width: '2px', // Width of the vertical line
              height: '50%', // Height of the vertical line
              backgroundColor: getStatusColor(item.machine_status),
              transform: 'translateX(-50%)',
            }}
          />
        </div>
      ))}
    </div>
    </center>
    </div>
  );
};

export default MachineStatusDivs;
